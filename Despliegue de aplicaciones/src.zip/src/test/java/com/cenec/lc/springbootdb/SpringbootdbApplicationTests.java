package com.cenec.lc.springbootdb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootdbApplicationTests {

	@Test
	void contextLoads() {
	}

}
